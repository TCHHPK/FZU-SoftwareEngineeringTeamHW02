<template>
  <div class="register-page">
    <el-card class="register-card">
      <h2 class="register-title">注册账号</h2>

      <el-form :model="form" @submit.prevent="handleRegister">
        <el-form-item>
          <el-input v-model="form.username" placeholder="请输入用户名" size="large" />
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.password" type="password" placeholder="请输入密码" show-password size="large" />
        </el-form-item>
        <el-button type="primary" native-type="submit" size="large" style="width: 100%;" :loading="loading">
          注册
        </el-button>
      </el-form>

      <div style="text-align: center; margin-top: 15px; font-size: 14px;">
        <span style="color: #666;">已有账号？</span>
        <el-link type="primary" @click="$router.push('/login')">去登录</el-link>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import http from '@/utils/http' // 👈 使用总机

const router = useRouter()
const loading = ref(false)
const form = reactive({ username: '', password: '' })

async function handleRegister() {
  if (!form.username || !form.password) return ElMessage.warning('请输入账号和密码')
  
  loading.value = true
  try {
    // 调用注册接口
    await http.post('/auth/register', form)
    
    // 因为拦截器处理过，能走到这里说明肯定是成功的
    ElMessage.success('注册成功，请登录！')
    router.push('/login')
  } catch (error) {
    // 拦截器已经弹红字了，这里不用写提示
    console.error(error)
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.register-page {
  /* 强制宽度撑满整个屏幕，高度撑满视口 */
  width: 100vw;
  height: 100vh;
  /* 绝对居中魔法 */
  display: flex;
  justify-content: center;
  align-items: center;
  /* 移除原本的背景，让全局的动态背景透出来 */
  background: transparent; 
}

.register-card {
  width: 400px;
  border-radius: 12px;
  /* 毛玻璃和阴影效果 */
  background: rgba(255, 255, 255, 0.9) !important;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  border: none;
}

.register-title {
  text-align: center;
  margin-bottom: 25px;
  font-size: 24px;
  color: #303133;
  font-weight: 600;
}
</style>