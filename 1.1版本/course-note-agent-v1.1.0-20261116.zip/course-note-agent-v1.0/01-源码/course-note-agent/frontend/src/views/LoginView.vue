<template>
  <div class="login-page">
    <el-card class="login-card">
      <h2 class="login-title">登录系统</h2>

      <el-form :model="form" @submit.prevent="handleLogin">
        <el-form-item>
          <el-input v-model="form.username" placeholder="请输入账号" size="large" />
        </el-form-item>
        <el-form-item>
          <el-input 
            v-model="form.password" 
            type="password" 
            placeholder="请输入密码" 
            show-password 
            size="large"
            @keyup.enter="handleLogin" 
          />
        </el-form-item>
        <el-button 
          type="primary" 
          native-type="submit" 
          size="large" 
          style="width: 100%;" 
          :loading="loading"
        >
          登录
        </el-button>
      </el-form>

      <div style="text-align: center; margin-top: 15px; font-size: 14px;">
        <span style="color: #666;">没有账号？</span>
        <el-link type="primary" @click="$router.push('/register')">去注册</el-link>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import http from '@/utils/http'

const router = useRouter()
const loading = ref(false)
const form = reactive({ username: '', password: '' })

async function handleLogin() {
  if (!form.username || !form.password) return ElMessage.warning('请输入账号和密码')
  
  loading.value = true
  try {
    // 直接拿返回的数据
    const res = await http.post('/auth/login', form)
    
    ElMessage.success('登录成功！')
    if (res.token) localStorage.setItem('token', res.token)
    router.push('/upload')
  } catch (error) {
    console.error(error)
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  /* 用交付包里那版设计的背景图，回退到渐变底色（图片加载失败时也好看） */
  background-image: url('@/assets/login-bg.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-color: #e0eafc;
}

.login-card {
  width: 400px;
  border-radius: 12px;
  /* 半透明的白色背景 */
  background: rgba(255, 255, 255, 0.9) !important;
  /* 毛玻璃模糊效果 */
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1) !important;
  border: 1px solid rgba(255, 255, 255, 0.3) !important;
}

.login-title {
  text-align: center;
  margin-bottom: 25px;
  font-size: 24px;
  color: #303133;
  font-weight: 600;
}
</style>