"""SQLite 连接管理。

两个数据库文件，对应 SRS 3.4「业务数据与领域知识物理或逻辑分离」：
    storage/business.db  用户、文档、任务、笔记、对话……
    storage/kb.db        公共领域知识库（管理员维护，Agent 只读）
"""

from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

BASE_DIR = Path(__file__).resolve().parents[2]
STORAGE_DIR = Path(os.getenv("STORAGE_DIR", BASE_DIR / "storage"))

BUSINESS_DB = Path(os.getenv("BUSINESS_DB", STORAGE_DIR / "business.db"))
KB_DB = Path(os.getenv("KB_DB", STORAGE_DIR / "kb.db"))
SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"
MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"


def _connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30, isolation_level=None, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 10000")
    return conn


@contextmanager
def business_db() -> Iterator[sqlite3.Connection]:
    conn = _connect(BUSINESS_DB)
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def kb_db() -> Iterator[sqlite3.Connection]:
    conn = _connect(KB_DB)
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    conn.execute("BEGIN")
    try:
        yield conn
    except Exception:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def init_databases(*, reset: bool = False) -> dict[str, str]:
    """建库建表。reset=True 时删除已有文件（仅开发期使用）。

    返回 {"business": 路径, "kb": 路径}。
    """
    if reset:
        for path in (BUSINESS_DB, KB_DB):
            for suffix in ("", "-wal", "-shm"):
                f = Path(str(path) + suffix)
                if f.exists():
                    f.unlink()

    schema = SCHEMA_PATH.read_text(encoding="utf-8")
    business_section, _, kb_section = schema.partition("-- 二、领域知识库")

    with business_db() as conn:
        conn.executescript(business_section)
        _migrate_business(conn)
        _apply_sql_migrations(conn)
    with kb_db() as conn:
        conn.executescript("-- 二、领域知识库" + kb_section)

    return {"business": str(BUSINESS_DB), "kb": str(KB_DB)}


def _apply_sql_migrations(conn: sqlite3.Connection) -> list[str]:
    """执行 app/db/migrations/*.sql（按文件名排序）。

    为什么单独放一个目录而不是全塞进 schema.sql：
        schema.sql 是"最终形态"的全量建表，多人并行开发时改它容易冲突；
        迁移目录按文件分工（002_learning_loop.sql 归学习闭环），
        每人只加自己的文件，合并时不会互相覆盖。

    每个迁移文件都要写成幂等的（CREATE TABLE IF NOT EXISTS / CREATE INDEX IF NOT EXISTS），
    这样重复执行 init_db 也不会报错，已上线的库也能靠它补齐新表。
    """
    applied: list[str] = []
    if not MIGRATIONS_DIR.exists():
        return applied
    for path in sorted(MIGRATIONS_DIR.glob("*.sql")):
        conn.executescript(path.read_text(encoding="utf-8"))
        applied.append(path.name)
    return applied


# 增量迁移：字段以 schema.sql 为准，这里保证已存在的库也能补上新字段
_BUSINESS_MIGRATIONS: list[tuple[str, str, str]] = [
    ("documents", "display_name", "TEXT NOT NULL DEFAULT ''"),
]


def _migrate_business(conn: sqlite3.Connection) -> None:
    for table, column, definition in _BUSINESS_MIGRATIONS:
        existing = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
    # 历史数据回填：display_name 为空时用 source_file 兜底
    conn.execute("UPDATE documents SET display_name = source_file WHERE display_name = ''")
