-- 002_learning_loop.sql
-- 学习闭环：智能自测、错题本、图形化思维导图
--
-- 归属说明（避免多人改同一文件）：
--   本文件由 徐张睿 建立（契约先行，先让所有人能并行开发）。
--   后续变更：自测两表由 徐张睿 维护，错题表由 沈文驰 维护，导图表由 陈瑀涵/蔡靖熹 维护。
--
-- 设计要点：
--   1. 答案只存服务端，取卷接口不下发；
--   2. 错题用 (user_id, source_type, source_id) 唯一键去重，重复答错只加次数；
--   3. 交卷幂等靠 self_tests.status，判过分的不再判；
--   4. 导图用邻接表（parent_id 自关联）存树，前端一次拉全树在内存里渲染。

-- ---------------------------------------------------------------- 自测
CREATE TABLE IF NOT EXISTS self_tests (
  test_id        INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  session_id     INTEGER REFERENCES sessions(session_id) ON DELETE SET NULL,
  course_name    TEXT    NOT NULL DEFAULT '',
  scope_text     TEXT    NOT NULL DEFAULT '',
  question_count INTEGER NOT NULL DEFAULT 5,
  -- draft: 已建卷未出题；ready: 可作答；graded: 已判分；failed: 出题失败
  status         TEXT    NOT NULL DEFAULT 'draft'
                 CHECK (status IN ('draft', 'ready', 'graded', 'failed')),
  total_score    REAL    NOT NULL DEFAULT 100,
  score          REAL    NOT NULL DEFAULT 0,
  correct_count  INTEGER NOT NULL DEFAULT 0,
  error_message  TEXT    NOT NULL DEFAULT '',
  created_at     TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  submitted_at   TEXT,
  graded_at      TEXT
);
CREATE INDEX IF NOT EXISTS idx_st_user ON self_tests(user_id, created_at);

CREATE TABLE IF NOT EXISTS self_test_items (
  item_id            INTEGER PRIMARY KEY AUTOINCREMENT,
  test_id            INTEGER NOT NULL REFERENCES self_tests(test_id) ON DELETE CASCADE,
  seq                INTEGER NOT NULL DEFAULT 0,
  knowledge_name     TEXT    NOT NULL DEFAULT '',
  question_type      TEXT    NOT NULL DEFAULT 'single'
                     CHECK (question_type IN ('single', 'judge', 'short')),
  stem               TEXT    NOT NULL,
  options_json       TEXT    NOT NULL DEFAULT '[]',
  answer             TEXT    NOT NULL DEFAULT '',
  analysis           TEXT    NOT NULL DEFAULT '',
  evidence_chunk_key TEXT    NOT NULL DEFAULT '',
  evidence_page      INTEGER,
  user_answer        TEXT,
  is_correct         INTEGER,
  score              REAL    NOT NULL DEFAULT 0,
  answered_at        TEXT
);
CREATE INDEX IF NOT EXISTS idx_sti_test ON self_test_items(test_id, seq);

-- ---------------------------------------------------------------- 错题本
CREATE TABLE IF NOT EXISTS wrong_questions (
  wrong_id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id            INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  knowledge_name     TEXT    NOT NULL,
  source_type        TEXT    NOT NULL DEFAULT 'self_test'
                     CHECK (source_type IN ('self_test', 'manual')),
  source_id          INTEGER NOT NULL,
  question_stem      TEXT    NOT NULL DEFAULT '',
  correct_answer     TEXT    NOT NULL DEFAULT '',
  analysis           TEXT    NOT NULL DEFAULT '',
  evidence_chunk_key TEXT    NOT NULL DEFAULT '',
  evidence_page      INTEGER,
  wrong_count        INTEGER NOT NULL DEFAULT 1,
  correct_streak     INTEGER NOT NULL DEFAULT 0,
  mastered           INTEGER NOT NULL DEFAULT 0,
  last_wrong_at      TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at         TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  -- 同一道题只记一条：重复答错走 UPDATE 累加次数，不产生第二行
  UNIQUE (user_id, source_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_wq_user_kp ON wrong_questions(user_id, knowledge_name);

-- ---------------------------------------------------------------- 思维导图
CREATE TABLE IF NOT EXISTS mindmap_nodes (
  node_id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id         INTEGER NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
  user_id            INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  parent_id          INTEGER REFERENCES mindmap_nodes(node_id) ON DELETE CASCADE,
  name               TEXT    NOT NULL,
  level              INTEGER NOT NULL DEFAULT 1,
  summary            TEXT    NOT NULL DEFAULT '',
  evidence_chunk_key TEXT    NOT NULL DEFAULT '',
  evidence_page      INTEGER,
  seq                INTEGER NOT NULL DEFAULT 0,
  created_at         TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mn_session ON mindmap_nodes(session_id, parent_id, seq);
